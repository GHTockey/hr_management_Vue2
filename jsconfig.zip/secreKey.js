import COS from "cos-js-sdk-v5";
const cos = new COS({
    SecretId: '',
    SecretKey: ''
});
export default cos