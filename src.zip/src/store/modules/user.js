import { login } from "@/api/user"
export default {
  namespaced: true,
  state: {
    token:''
  },
  mutations: {
    updateToken: (state,payload) => state.token = payload,
  },
  actions: {
    async getLoginToken(context,params) {
      let res = await login(params);
      console.log(res,context);
      // context.commit('',res.data);
    }
  },
  getters: {

  }
}