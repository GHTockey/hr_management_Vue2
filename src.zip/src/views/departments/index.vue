<template>
  <div class="dashboard-container">
    <div class="app-container">
      <h2>
        ├── departments         # 组织架构
      </h2>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
